const express = require('express')
const Recruiter = require('./model')
const bodyParser = require('body-parser')


// initialize our express app
const app = express()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}))


let recruiter = new Recruiter({
  name:'Chesare',
  email:'chesare@gmail.com',
  phone:'23123123123123',
  qualification:'jefe',
  location:'unknown',
  expertise:1,
  expertise_biological:1,
  expertise_pcr:1,
  availability:1
})

console.log('key->', {a: '1'} )

recruiter.save(function (err) {
    if (err) {
        console.log('error ->', err)
    }
    console.log('Recruiter Created successfully')
})

const find = async function() {
  let recruits = await Recruiter.find({})
  console.log(recruits)
}()





app.listen(8080, () => {
    console.log('Server is up and running on port numner 8080')
})
