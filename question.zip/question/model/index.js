const mongoose = require('mongoose');

let USER = process.env.DBUSER
let PASSWORD = process.env.DBPASSWORD
let HOSTNAME = process.env.DBHOSTNAME

let dev_db_url = 'mongodb://user:UU7WD673RSCol01n@127.0.0.1:27017/recruiter';
let mongoDB = process.env.MONGODB_URI || dev_db_url;
mongoose.connect(mongoDB);
mongoose.Promise = global.Promise;
let db = mongoose.connection;
//db.on('error', console.error.bind(console, 'MongoDB connection error:'));

console.log('??')

module.exports = require('./recruiter')
